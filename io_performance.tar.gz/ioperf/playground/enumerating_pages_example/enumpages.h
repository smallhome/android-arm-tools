#ifndef _ENUMPAGES_H
#define _ENUMPAGES_H

extern long enum_cached_pages(const char *filename);

#endif
