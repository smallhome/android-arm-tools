hatless.fox@gmail.com

mock file system

Usage:
$ modprobe mimfs
$ mount -t mimfs <device> <root>

params:
blk_sz_bits -- number of bits in page size. 12 be default
