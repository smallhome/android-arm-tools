shabalyn.a@gmail.com

backend - kernel tracing module
io_tracing - IO stack tracing 

Usage:
echo 1 > /sys/kernel/debug/tracing/events/io-bench/enable
cat /sys/kernel/debug/tracing/trace

