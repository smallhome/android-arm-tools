vadim.lomshakov@gmail.com

set tests:
 + sequential reads
 + random reads

Need install:
<code>sudo apt-get install fio</code> (version 1.59)

Usage:
<code>$ python2 test.py </code>