This folder contains different artifacts that makes development/research process more fun and easier
