#!/bin/sh
# Exit with no output.
exit 0
