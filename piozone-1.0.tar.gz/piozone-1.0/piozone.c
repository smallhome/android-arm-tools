/*
** piozone.c - Disk I/O Benchmarking Tool
**
** Copyright (c) 2002 Peter Eriksson <pen@lysator.liu.se>
**
** This program is free software; you can redistribute it and/or
** modify it as you wish - as long as you don't claim that you wrote
** it.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>
#include <signal.h>

#define KiB ((uint64_t) 1024)
#define MiB ((uint64_t) 1024*KiB)
#define GiB ((uint64_t) 1024*MiB)

#define KB  ((uint64_t) 1000)
#define MB  ((uint64_t) 1000*KB)
#define GB  ((uint64_t) 1000*MB)

static char iobuf[1*MiB];
static volatile stopf = 0;
static char *argv0 = "piozone";

int debug = 0;
int verbose = 0;

extern char version[];

	   
void
sigalrm_handler(int f)
{
	stopf = 1;
}

void
print_dial()
{
    static int i;
    static char *dials = "|/-\\";
    static time_t saved_t;
    time_t now_t;

    time(&now_t);
    if (now_t != saved_t)
    {
	saved_t = now_t;
	putchar(dials[i]);
	putchar('\b');
	fflush(stdout);
	i = (i+1)&3;
    }
}

int
bench_linear(int fd,
	     uint64_t off,
	     int ts,
	     uint64_t len)
{
    int count = 0;
    int nr = 0;
    
    llseek(fd, off, SEEK_SET);
    signal(SIGALRM, sigalrm_handler);
    stopf = 0;
    printf("Testing... ");
    alarm(ts);
    while (!stopf && (nr = read(fd, iobuf, len)) == len)
    {
	print_dial();
	++count;
    }
    alarm(0);
    if (!stopf)
    {
	if (nr < 0 && errno != EINTR && errno != EIO)
	    printf("\rAborted (end of disk?): %s\n", strerror(errno));
	else
	    fputs("\r                    \r", stdout);
	
	fflush(stdout);
	return -1;
    }

    printf("\r%4.1f MB/s at offset %3d GB using %3d %ciB reads\n",
	   (double) ((uint64_t) count * len / MiB) / ts,
	   (int) (off/GB),
	   (int) (len > 1*MiB ? (len / MiB) : (len / KiB)),
	   (len > 1*MiB ? 'M' : 'K'));

    return 0;
}


int
bench_random(int fd,
	     uint64_t off,
	     int ts,
	     uint64_t len,
	     int area)
{
    int count = 0;
    int nr = 0;
    
    
    signal(SIGALRM, sigalrm_handler);
    stopf = 0;
    printf("Testing... ");
    alarm(ts);
    while (!stopf &&
	   llseek(fd, off+((rand()&area)*MiB), SEEK_SET) != -1 &&
	   (nr = read(fd, iobuf, len)) == len)
    {
	print_dial();
	++count;
    }
    alarm(0);
    if (!stopf)
    {
	if (nr < 0 && errno != EINTR && errno != EIO)
	    printf("\rAborted (end of disk?): %s\n", strerror(errno));
	else
	    fputs("\r                    \r", stdout);
	
	fflush(stdout);
	return -1;
    }

    printf("\r%4.1f MB/s at offset %3d GB using %3d %ciB reads\n",
	   (double) ((uint64_t) count * len / MiB) / ts,
	   (int) (off/GB),
	   (int) (len > 1*MiB ? (len / MiB) : (len / KiB)),
	   (len > 1*MiB ? 'M' : 'K'));

    return 0;
}


uint64_t
disksize(int fd)
{
    char buf[8*KiB];
    uint64_t off, del;
    

    off = 0;
    del = 64*GiB;

    while (del > 8*KiB && llseek(fd, off+del, SEEK_SET) != -1)
    {
	if (read(fd, buf, 8*KiB) < 0)
	    del >>= 1;
	else
	    off += del;
    }

    return off;
}

void
usage(FILE *fp)
{
    fprintf(fp,
	    "Usage: %s [-dvh] [-t <seconds>] <device> [<interval>]\n",
	    argv0);
}


int
main(int argc,
     char *argv[])
{
    int fd, dsize, i;
    uint64_t off, delta;
    int test_time = 30; /* seconds */
    int c;


    argv0 = argv[0];

    while ((c = getopt(argc, argv, "dvht:")) != -1)
	switch (c)
	{
	  case 'd':
	    debug++;
	    break;
	    
	  case 'v':
	    verbose++;
	    break;

	  case 'h':
	    usage(stdout);
	    exit(0);

	  case 't':
	    if (sscanf(optarg, "%u", &test_time) != 1)
	    {
		fprintf(stderr, "%s: invalid -t argument: %s\n",
			argv[0], optarg);
		exit(1);
	    }
	    break;

	  default:
	    fprintf(stderr, "%s: invalid option: %s\n",
		    argv[0], optarg);
	    exit(1);
	}
	    
		  
    if (optind >= argc)
    {
	usage(stderr);
	exit(1);
    }

    fd = open(argv[optind], O_RDONLY);
    if (fd < 0)
    {
	fprintf(stderr, "%s: %s: open failed: %s\n",
		argv[0], argv[optind], strerror(errno));
	exit(1);
    }


    ++optind;
    
    off = disksize(fd);

    printf("[PIOZONE, version %s - Copyright (c) 2002 Peter Eriksson <pen@lysator.liu.se>]\n\n",
	   version);
	
    if (verbose)
	printf("Disk size: %lld GB (%lld GiB)\n\n", off / GB, off / GiB);
    
    if (optind >= argc)
	delta = (off - 1*GiB) / 2;
    else
	delta = atoi(argv[optind])*GB;

    puts("Linear read transfer rates:");
    for (off = 0; bench_linear(fd, off, test_time, 64*KiB) == 0; off+=delta)
	;
    putchar('\n');
    for (off = 0; bench_linear(fd, off, test_time, 1*MiB) == 0; off+=delta)
	;
    
    puts("\nRandom access read transfer rates (area size: 1 GiB):");
    for (off = 0; bench_random(fd, off, test_time, 64*KiB, 1023) == 0; off+=delta)
	;
    putchar('\n');
    for (off = 0; bench_random(fd, off, test_time, 1*MiB, 1023) == 0; off+=delta)
	;
    
    return 0;
}
