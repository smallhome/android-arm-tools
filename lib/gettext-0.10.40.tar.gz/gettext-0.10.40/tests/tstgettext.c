/* A version of the gettext program that uses the included libintl.  */
#define TESTS
#include "../src/gettext.c"
