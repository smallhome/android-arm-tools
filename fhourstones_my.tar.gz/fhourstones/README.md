The Fhourstones benchmark
=========================

This is the GitHub home of the Fhourstones benchmark by John Tromp.

Homepage: http://tromp.github.io/


