/* 
 * Benchmarking.h created by phr on 2001-01-13 16:23:45 +0000
 *
 * Project GSBench
 *
 * Created with ProjectCenter - http://www.projectcenter.ch
 *
 * $Id: Benchmarking.h,v 1.1.1.1 2001/01/13 20:48:31 robert Exp $
 */

@protocol Benchmarking <NSObject>

- (void)prepareForBenchmarking:(id)sender;
- (NSString *)menuItemTitle;

@end
