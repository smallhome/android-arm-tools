/* 
 * BundleController.h created by phr on 2001-01-13 14:42:33 +0000
 *
 * Project GSBench
 *
 * Created with ProjectCenter - http://www.projectcenter.ch
 *
 * $Id: BundleController.h,v 1.1.1.1 2001/01/13 20:48:30 robert Exp $
 */

#import <AppKit/AppKit.h>

@interface BundleController : NSObject
{
  NSDictionary *bundlesToLoad;
  NSString *bundlePath;
  NSMutableArray *loadedBundles;
}

- (id)init;
- (void)dealloc;

- (void)loadBundles;
- (void)registerBundle:(NSBundle *)bundle;

@end

extern NSString *BundleControllerLoadingException;

