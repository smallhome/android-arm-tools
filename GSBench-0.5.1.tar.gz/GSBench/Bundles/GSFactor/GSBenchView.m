/* 
 * GSBenchView.m created by phr on 2001-01-13 21:53:24 +0000
 *
 * Project GSFactor
 *
 * Created with ProjectCenter - http://www.projectcenter.ch
 *
 * $Id: GSBenchView.m,v 1.2 2001/01/14 12:48:41 robert Exp $
 */

#import "GSBenchView.h"
#include <sys/time.h>
#include <unistd.h>

@implementation GSBenchView

- (id)initWithFrame:(NSRect)aRect
{
    if(self = [super initWithFrame:aRect]) {
      meanResult = 0.0f;
    }
    return self;
}

- (void)setMatrix:(NSMatrix *)aMatrix;
{
  result = aMatrix;
}

- (void)drawRect:(NSRect)aRect
{
  PSsetgray(1.0);
  NSRectFill(aRect);
}

- (void)runBenchmark
{
  NSSize size;
  
  size = [[NSScreen mainScreen] frame].size;
  
  srand(1);
  srandom(1);
  
  [self line];
  [NSThread sleepUntilDate:[NSDate dateWithTimeIntervalSinceNow:(1)]];
  
  [self curve];
  [NSThread sleepUntilDate:[NSDate dateWithTimeIntervalSinceNow:(1)]];
  
  [self fill];
  [NSThread sleepUntilDate:[NSDate dateWithTimeIntervalSinceNow:(1)]];
  
  [self trans];
  [NSThread sleepUntilDate:[NSDate dateWithTimeIntervalSinceNow:(1)]];
  
  [self composite];
  [NSThread sleepUntilDate:[NSDate dateWithTimeIntervalSinceNow:(1)]];
  
  [self text];
  [NSThread sleepUntilDate:[NSDate dateWithTimeIntervalSinceNow:(1)]];
  
  [self windowTest];
  
  // Result
  meanResult = (resLine + 
		resCurve + 
		resFill + 
		resTrans + 
		resText + 
		resComposite + 
		resWindowTest)/7.0;
}

/*
 *
 *
 */

- (float)meanResult
{
  return meanResult;
}

- (int)currentTimeInMs
{
    struct timeval curTime;
    
    gettimeofday (&curTime, NULL);
    return ((curTime.tv_sec) * 1000 + curTime.tv_usec / 1000);
}

- (void)line
{
  int i,j,k, stopTime;
  int w = (int)[self bounds].size.width;
  int h = (int)[self bounds].size.height;
  
  [self lockFocus];
  
  PSsetlinewidth(1.0);
  stopTime = [self currentTimeInMs];
  for(j=0; j < 100; j++) {
    for (k=0; k < 100; k++) {
      i = k + 100 * j;
      PSsethsbcolor(((float)(i%32)) / 32.0, 1.0, 1.0);
      PSmoveto((float) ((i+120) % w),
	       (float) (i % h));
      PSlineto((float) ((i+40) % w),
	       (float) ((i+240) % h));
      PSstroke();
      [[self window] flushWindow];
    }
  }
  [self unlockFocus];
  
  stopTime = [self currentTimeInMs] - stopTime;
  resLine = (1000000.0/(float)stopTime/25.5643);
  [[result cellAtRow:0 column:1] setFloatValue:resLine];
}

- (void)curve
{
  int i,j,k, stopTime;
  int w = (int)[self bounds].size.width;
  int h = (int)[self bounds].size.height;
  
  stopTime = [self currentTimeInMs];
  
  [self lockFocus];
  PSmoveto(100.0, 100.0);
  for(j=0; j < 100; j++) {
    for (k=0; k < 50; k++) {
      i = k + 100 * j;
      PSsethsbcolor(((float)(i%32)) / 32.0, 1.0, 1.0);

      PSmoveto((float) ((i+120) % w),
	       (float) ((i+10) % h));
      PSrcurveto((float) ((i) % w),
		 (float) ((i+20) % h),
		 (float) ((i+420) % w),
		 (float) ((i) % h),
		 (float) ((i+320) % w),
		 (float) ((i+12) % h));
      PSstroke();
      [[self window] flushWindow];
    }
  }
  [self unlockFocus];
  
  stopTime = [self currentTimeInMs] - stopTime;
  resCurve = (1000000.0/(float)stopTime/47.6054);
  [[result cellAtRow:1 column:1] setFloatValue:resCurve];
}

- (void)fill
{
  int i,j,k, stopTime;
  int w = (int)[self bounds].size.width;
  int h = (int)[self bounds].size.height;
  
  stopTime = [self currentTimeInMs];
  
  [self lockFocus];
  PSmoveto(100.0, 100.0);
  for(j=0; j < 100; j++) {
    for (k=0; k < 50; k++) {
      i = k + 100 * j;
      PSsethsbcolor(((float)(i%32)) / 32.0, 1.0, 1.0);

      PSrectfill((float)(rand() % w), (float)(rand() % h), 100.0, 100.0);
      [[self window] flushWindow];
    }
  }
  [self unlockFocus];
  
  stopTime = [self currentTimeInMs] - stopTime;
  resFill = (1000000.0/(float)stopTime/92.0640);
  [[result cellAtRow:2 column:1] setFloatValue:resFill];
}

- (void)trans
{
  int i, stopTime;
  
  stopTime = [self currentTimeInMs];
  
  [self lockFocus];
  [[NSFont userFontOfSize: 144] set];
  PSmoveto(10.0 , 70.0);
  PSselectfont([[[NSFont userFontOfSize: 144] fontName] cString],144);
  for (i=0; i < 150; i++) {
    PSgsave();
    PSsethsbcolor(((float)(i%32)) / 32.0, 1.0, 1.0);

    PSscale((float)(rand()%40)/10.0+0.1, (float)(rand()%40)/10.0+0.1);
    PSshow("GNUstep");
    PSrotate((float)(rand()%360));
    PSshow("GNUstep");
    PStranslate((float)(rand()%200)/10.0-10.0,
		(float)(rand()%200)/10.0-10.0);
    PSshow("GNUstep");
    [[self window] flushWindow];
    PSgrestore();
  }
  [self unlockFocus];
  
  stopTime = [self currentTimeInMs] - stopTime;
  resTrans = (1000000.0/(float)stopTime/47.1965);
  [[result cellAtRow:3 column:1] setFloatValue:resTrans];
}

- (void)text
{
  int i,j,k, stopTime;
  int w = (int)[self bounds].size.width;
  int h = (int)[self bounds].size.height;
  char s[9];
  
  stopTime = [self currentTimeInMs];
  
  [self lockFocus];
  [[NSFont userFontOfSize: 72] set];
  PSselectfont([[[NSFont userFontOfSize: 72] fontName] cString],72);
  //    PSselectfont("Times-Roman",72.0);
  for(j=0; j < 100; j++) {
    for (k=0; k < 50; k++) {
      i = k + 100 * j;
      PSsethsbcolor(((float)(i%32)) / 32.0, 1.0, 1.0);

      PSmoveto((float) (rand() % w),
	       (float) (rand() % h));
      s[0] = 'R' + rand()%10; s[1] = 'h' + rand()%22;
      s[2] = 'a' + rand()%3;  s[3] = 'p' + rand()%6;
      s[4] = 's' + rand()%7; s[5] = 'o' + rand()%6;
      s[6] = 'd' + rand()%22; s[7] = 'y' + rand()%8;
      s[8] = '\0';
      PSshow(s);
      [[self window] flushWindow];
    }
  }
  [self unlockFocus];
  
  stopTime = [self currentTimeInMs] - stopTime;
  resText = (1000000.0/(float)stopTime/37.3552);
  [[result cellAtRow:4 column:1] setFloatValue:resText];
}

- (void)composite
{
  int i,j,k, stopTime;
  int w = (int)[self bounds].size.width;
  int h = (int)[self bounds].size.height;
  
  stopTime = [self currentTimeInMs];
  
  [self lockFocus];
  for(j=0; j < 100; j++) {
    for (k=0; k < 100; k++) {
      i = k + 100 * j;
      PScomposite((float) (i % w), (float) (rand() % h), 100.0, 100.0,
		  [[self window] gState], 50.0, 50.0, NSCompositeCopy);
      PScomposite((float) (rand() % w), (float) (i % h), 100.0, 100.0,
		  [[self window] gState], 170.0, 50.0, NSCompositeCopy);
      PScomposite((float) (i % w), (float) (rand() % h), 100.0, 100.0,
		  [[self window] gState], 170.0, 170.0, NSCompositeCopy);
      PScomposite((float) (rand() % w), (float) (i % h), 100.0, 100.0,
		  [[self window] gState], 50.0, 170.0, NSCompositeCopy);
      [[self window] flushWindow];
    }
  }
  [self unlockFocus];
  
  stopTime = [self currentTimeInMs] - stopTime;
  resComposite = (1000000.0/(float)stopTime/8.81096);
  [[result cellAtRow:5 column:1] setFloatValue:resComposite];
}

- (void)windowTest
{
  int i, j, stopTime;
  float x,y;
  NSRect theRect;
  
  stopTime = [self currentTimeInMs];
  
  theRect = [[self window] frame];
  x = theRect.origin.x;
  y = theRect.origin.y;
  
  for (j=0; j < 10; j++) {
    for (i=0; i < 25; i++) {
      [[self window] setFrameOrigin:NSMakePoint(++x, ++y)];
    }
    for (i=0; i < 25; i++) {
      [[self window] setFrameOrigin:NSMakePoint(++x, --y)];
    }
    for (i=0; i < 25; i++) {
      [[self window] setFrameOrigin:NSMakePoint(--x, --y)];
    }
    for (i=0; i < 25; i++) {
      [[self window] setFrameOrigin:NSMakePoint(--x, ++y)];
    }
    for (i=0; i < 10; i++) {
      [[self window] orderOut:self];
      [[self window] orderFront:self];
    }
  }
  [[self window] makeKeyAndOrderFront:self];
  
  stopTime = [self currentTimeInMs] - stopTime;
  resWindowTest = (1000000.0/(float)stopTime/18.01);
  [[result cellAtRow:6 column:1] setFloatValue:resWindowTest];
}

@end
