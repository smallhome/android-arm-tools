/* 
 * GSFactorController.m created by phr on 2001-01-13 16:53:45 +0000
 *
 * Project GSFactor
 *
 * Created with ProjectCenter - http://www.projectcenter.ch
 *
 * $Id: GSFactorController.m,v 1.2 2001/01/14 12:48:41 robert Exp $
 */

#import "GSFactorController.h"
#import "GSBenchView.h"

#define TITLE @"GSFactor"

@interface GSFactorController (Private)

- (void)_createUI;

@end

@implementation GSFactorController (Private)

- (void)_createUI
{
  unsigned int style = NSTitledWindowMask | NSClosableWindowMask;
  NSRect _w_frame;
  NSBox *line;
  NSCell *matrixCell = [[NSActionCell alloc] init];

  _w_frame = NSMakeRect(200,300,640,560);
  factorWindow = [[NSWindow alloc] initWithContentRect:_w_frame
				   styleMask:style
				   backing:NSBackingStoreBuffered
				   defer:YES];
  [factorWindow setMinSize:NSMakeSize(640,560)];
  [factorWindow setTitle:@"GSFactor"];
  [factorWindow setDelegate:self];
  [factorWindow setReleasedWhenClosed:NO];
  [factorWindow center];
  [factorWindow setFrameAutosaveName:@"GSFactorWindow"];

  factorField = [[NSTextField alloc] initWithFrame:NSMakeRect(0,512,640,28)];
  [factorField setAlignment: NSCenterTextAlignment];
  [factorField setBordered: NO];
  [factorField setEditable: NO];
  [factorField setBezeled: NO];
  [factorField setDrawsBackground: NO];
  [factorField setFont:[NSFont boldSystemFontOfSize:20]];
  [factorField setStringValue:@"GSFactor PS Benchmark"];
  [[factorWindow contentView] addSubview:factorField];
  RELEASE(factorField);

  line = [[NSBox alloc] init];
  [line setTitlePosition:NSNoTitle];
  [line setFrame:NSMakeRect(0,480,640,2)];
  [[factorWindow contentView] addSubview:line];
  RELEASE(line);

  line = [[NSBox alloc] init];
  [line setTitlePosition:NSNoTitle];
  [line setFrame:NSMakeRect(16,64,418,402)];
  [[factorWindow contentView] addSubview:line];
  RELEASE(line);

  _w_frame = NSMakeRect(-1,-1,416,400);
  view = [[GSBenchView alloc] initWithFrame:_w_frame];
  [line addSubview:view];

  factorButton = [[NSButton alloc] initWithFrame:NSMakeRect(536,16,88,22)];
  [factorButton setTitle:@"GSFactor"];
  [factorButton setAlternateTitle:@"Running..."];
  [factorButton setButtonType:NSToggleButton];
  [factorButton setTarget:self];
  [factorButton setAction:@selector(run:)];
  [[factorWindow contentView] addSubview:factorButton];

  line = [[NSBox alloc] init];
  [line setTitle:@"Results"];
  [line setFrame:NSMakeRect(454,252,160,222)];
  [[factorWindow contentView] addSubview:line];
  RELEASE(line);

  _w_frame = NSMakeRect(0,0,144,184);
  factorMatrix = [[NSMatrix alloc] initWithFrame: _w_frame
				   mode: NSListModeMatrix
				   prototype: matrixCell
				   numberOfRows:7
				   numberOfColumns:2];
  [factorMatrix sizeToCells];
  [factorMatrix setSelectionByRect:YES];
  [line addSubview:factorMatrix];
  RELEASE(matrixCell);

  [view setMatrix:factorMatrix];

  /*
   *
   */

  matrixCell = [factorMatrix cellAtRow:0 column:0];
  [matrixCell setStringValue:@"Line"];
  [matrixCell setEditable: NO];
  [matrixCell setBezeled: NO];

  matrixCell = [factorMatrix cellAtRow:0 column:1];
  [matrixCell setFloatValue:0.0];
  [matrixCell setEditable: NO];
  [matrixCell setBezeled: YES];

  /*
   *
   */

  matrixCell = [factorMatrix cellAtRow:1 column:0];
  [matrixCell setStringValue:@"Curve"];
  [matrixCell setEditable: NO];
  [matrixCell setBezeled: NO];

  matrixCell = [factorMatrix cellAtRow:1 column:1];
  [matrixCell setFloatValue:0.0];
  [matrixCell setEditable: NO];
  [matrixCell setBezeled: YES];

  /*
   *
   */

  matrixCell = [factorMatrix cellAtRow:2 column:0];
  [matrixCell setStringValue:@"Fill"];
  [matrixCell setEditable: NO];
  [matrixCell setBezeled: NO];

  matrixCell = [factorMatrix cellAtRow:2 column:1];
  [matrixCell setFloatValue:0.0];
  [matrixCell setEditable: NO];
  [matrixCell setBezeled: YES];

  /*
   *
   */

  matrixCell = [factorMatrix cellAtRow:3 column:0];
  [matrixCell setStringValue:@"Trans"];
  [matrixCell setEditable: NO];
  [matrixCell setBezeled: NO];

  matrixCell = [factorMatrix cellAtRow:3 column:1];
  [matrixCell setFloatValue:0.0];
  [matrixCell setEditable: NO];
  [matrixCell setBezeled: YES];

  /*
   *
   */

  matrixCell = [factorMatrix cellAtRow:4 column:0];
  [matrixCell setStringValue:@"Text"];
  [matrixCell setEditable: NO];
  [matrixCell setBezeled: NO];

  matrixCell = [factorMatrix cellAtRow:4 column:1];
  [matrixCell setFloatValue:0.0];
  [matrixCell setEditable: NO];
  [matrixCell setBezeled: YES];

  /*
   *
   */

  matrixCell = [factorMatrix cellAtRow:5 column:0];
  [matrixCell setStringValue:@"Composite"];
  [matrixCell setEditable: NO];
  [matrixCell setBezeled: NO];

  matrixCell = [factorMatrix cellAtRow:5 column:1];
  [matrixCell setFloatValue:0.0];
  [matrixCell setEditable: NO];
  [matrixCell setBezeled: YES];

  /*
   *
   */

  matrixCell = [factorMatrix cellAtRow:6 column:0];
  [matrixCell setStringValue:@"Window"];
  [matrixCell setEditable: NO];
  [matrixCell setBezeled: NO];

  matrixCell = [factorMatrix cellAtRow:6 column:1];
  [matrixCell setFloatValue:0.0];
  [matrixCell setEditable: NO];
  [matrixCell setBezeled: YES];

  line = [[NSBox alloc] init];
  [line setTitle:@"GSFactor"];
  [line setFrame:NSMakeRect(454,124,160,72)];
  [[factorWindow contentView] addSubview:line];
  RELEASE(line);

  factorField = [[NSTextField alloc] initWithFrame:NSMakeRect(8,8,128,21)];
  [factorField setAlignment: NSRightTextAlignment];
  [factorField setBordered: YES];
  [factorField setEditable: NO];
  [factorField setBezeled: YES];
  [factorField setDrawsBackground: YES];
  [factorField setFloatValue:0.0];
  [line addSubview:factorField];
}

@end

@implementation GSFactorController

- (id)init
{
  if ((self = [super init])) {
    [self _createUI];
  }
  return self;
}

- (void)dealloc
{
  RELEASE(factorWindow);
  RELEASE(factorButton);
  RELEASE(factorField);
  RELEASE(factorMatrix);
  RELEASE(view);

  [super dealloc];
}

- (void)prepareForBenchmarking:(id)sender
{
  if ([factorWindow isVisible] == NO) {
    [factorWindow center];
  }

  [factorWindow makeKeyAndOrderFront:self];
}

- (NSString *)menuItemTitle
{
  return TITLE;
}

- (void)run:(id)sender
{
  NSRunAlertPanel(@"Running GSFactor",@"While running the benchmark the mouse will disappear. To get reliable results please quit all other applications.", @"OK", nil, nil);

  [factorWindow display];

  [[NSWorkspace sharedWorkspace] hideOtherApplications];
  [NSCursor hide];
  
  [factorWindow center];
  [view runBenchmark];
  
  [NSCursor unhide];

  [factorButton setNextState];  
  [factorField setFloatValue:[view meanResult]];
}

@end


