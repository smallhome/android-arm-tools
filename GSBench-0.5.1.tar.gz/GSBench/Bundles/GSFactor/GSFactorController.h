/* 
 * GSFactorController.h created by phr on 2001-01-13 16:53:47 +0000
 *
 * Project GSFactor
 *
 * Created with ProjectCenter - http://www.projectcenter.ch
 *
 * $Id: GSFactorController.h,v 1.3 2002/01/07 15:47:49 probert Exp $
 */

#import <AppKit/AppKit.h>
#import "../../App/Benchmarking.h"

@class GSBenchView;

@interface GSFactorController : NSObject <Benchmarking>
{
  NSButton *factorButton;
  NSWindow *factorWindow;
  NSMatrix *factorMatrix;
  NSTextField *factorField;
  GSBenchView *view;
}

- (id)init;
- (void)dealloc;

- (void)prepareForBenchmarking:(id)sender;
- (NSString *)menuItemTitle;

- (void)run:(id)sender;

@end
