/* 
 * GSBenchView.h created by phr on 2001-01-13 21:53:25 +0000
 *
 * Project GSFactor
 *
 * Created with ProjectCenter - http://www.projectcenter.ch
 *
 * $Id: GSBenchView.h,v 1.2 2001/01/14 12:48:41 robert Exp $
 */

#import <AppKit/AppKit.h>

@interface GSBenchView : NSView
{
  float meanResult;

  float resLine;
  float resCurve;
  float resFill;
  float resTrans;
  float resText;
  float resComposite;
  float resWindowTest;

  NSMatrix *result;
}

- (id)initWithFrame:(NSRect)aRect;

- (void)setMatrix:(NSMatrix *)aMatrix;

- (void)drawRect:(NSRect)aRect;

- (void)runBenchmark;
- (float)meanResult;
- (int)currentTimeInMs;

- (void)line;
- (void)curve;
- (void)fill;
- (void)trans;
- (void)text;
- (void)composite;
- (void)windowTest;

@end
