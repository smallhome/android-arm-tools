/* 
 * DhryController.h created by phr on 2001-01-13 20:46:44 +0000
 *
 * Project Dhry
 *
 * Created with ProjectCenter - http://www.projectcenter.ch
 *
 * $Id: DhryController.h,v 1.3 2002/01/07 15:47:46 probert Exp $
 */

#import <AppKit/AppKit.h>
#import "../../App/Benchmarking.h"

@interface DhryController : NSObject <Benchmarking>
{
  NSWindow *dhryWindow;
  NSButton *dhryButton;
  NSTextField *dhryField;
}

- (id)init;
- (void)dealloc;

- (void)prepareForBenchmarking:(id)sender;
- (NSString *)menuItemTitle;

- (void)run:(id)sender;

@end
