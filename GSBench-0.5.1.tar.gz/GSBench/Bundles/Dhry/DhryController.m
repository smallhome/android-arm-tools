/* 
 * DhryController.m created by phr on 2001-01-13 20:46:43 +0000
 *
 * Project Dhry
 *
 * Created with ProjectCenter - http://www.projectcenter.ch
 *
 * $Id: DhryController.m,v 1.3 2001/01/14 12:49:08 robert Exp $
 */

#import "DhryController.h"

#include "dhry.h"

#define TITLE @"Dhrystone"

@interface DhryController (Private)

- (void)_createUI;

@end

@implementation DhryController (Private)

- (void)_createUI
{
  unsigned int style = NSTitledWindowMask | NSClosableWindowMask;
  NSRect _w_frame;
  NSBox *line;

  _w_frame = NSMakeRect(200,300,320,200);
  dhryWindow = [[NSWindow alloc] initWithContentRect:_w_frame
                                           styleMask:style
                                             backing:NSBackingStoreBuffered
                                               defer:YES];
  [dhryWindow setMinSize:NSMakeSize(320,200)];
  [dhryWindow setTitle:@"Dhrystones"];
  [dhryWindow setDelegate:self];
  [dhryWindow setReleasedWhenClosed:NO];
  [dhryWindow center];
  [dhryWindow setFrameAutosaveName:@"DhrystonesWindow"];

  dhryField = [[NSTextField alloc] initWithFrame:NSMakeRect(0,148,320,28)];
  [dhryField setAlignment: NSCenterTextAlignment];
  [dhryField setBordered: NO];
  [dhryField setEditable: NO];
  [dhryField setBezeled: NO];
  [dhryField setDrawsBackground: NO];
  [dhryField setFont:[NSFont boldSystemFontOfSize:20]];
  [dhryField setStringValue:@"Dhrystones 2.1"];
  [[dhryWindow contentView] addSubview:dhryField];
  RELEASE(dhryField);

  line = [[NSBox alloc] init];
  [line setTitlePosition:NSNoTitle];
  [line setFrame:NSMakeRect(0,124,320,2)];
  [[dhryWindow contentView] addSubview:line];
  RELEASE(line);

  dhryField = [[NSTextField alloc] initWithFrame:NSMakeRect(16,64,60,21)];
  [dhryField setAlignment: NSRightTextAlignment];
  [dhryField setBordered: NO];
  [dhryField setEditable: NO];
  [dhryField setBezeled: NO];
  [dhryField setDrawsBackground: NO];
  [dhryField setStringValue:@"Result:"];
  [[dhryWindow contentView] addSubview:dhryField];
  RELEASE(dhryField);

  dhryField = [[NSTextField alloc] initWithFrame:NSMakeRect(84,64,184,21)];
  [dhryField setAlignment: NSRightTextAlignment];
  [dhryField setBordered: NO];
  [dhryField setEditable: NO];
  [dhryField setBezeled: YES];
  [dhryField setDrawsBackground:YES];
  [dhryField setFloatingPointFormat:YES left:5 right:3];
  [[dhryWindow contentView] addSubview:dhryField];

  dhryButton = [[NSButton alloc] initWithFrame:NSMakeRect(220,16,88,22)];
  [dhryButton setTitle:@"Run"];
  [dhryButton setAlternateTitle:@"Running..."];
  [dhryButton setButtonType:NSToggleButton];
  [dhryButton setTarget:self];
  [dhryButton setAction:@selector(run:)];
  [[dhryWindow contentView] addSubview:dhryButton];
}

@end

@implementation DhryController

- (id)init
{
  if ((self = [super init])) {
    [self _createUI];
  }
  return self;
}

- (void)dealloc
{
  RELEASE(dhryWindow);
  RELEASE(dhryButton);
  RELEASE(dhryField);

  [super dealloc];
}

- (void)prepareForBenchmarking:(id)sender
{
  if ([dhryWindow isVisible] == NO) {
    [dhryWindow center];
  }

  [dhryWindow makeKeyAndOrderFront:self];
}

- (NSString *)menuItemTitle
{
  return TITLE;
}

- (void)run:(id)sender
{
  NSRunAlertPanel(@"Running Dhrystones",@"While running the dhrystones benchmark the mouse will disappear. To get reliable results please quit all other applications.", @"OK", nil, nil);

  [dhryWindow display];

  [[NSWorkspace sharedWorkspace] hideOtherApplications];
  [NSCursor hide];
  [dhryField setFloatValue:dhry_main()];
  [dhryButton setNextState];
  [NSCursor unhide];
}

@end


